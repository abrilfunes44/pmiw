
function cargarTexto() {

  texto [0] = "Presiona ENTER para empezar";
  texto [1] = "Perdiste! Presiona R para reiniciar o C para ver los creditos";
  texto [2] = "Ganaste! Presiona R para jugar otra vez o C para ver los creditos";
  texto [3] = "REGLAS"
  texto [4] = "Para ganar, tenes que \nesquivar los autos.\n Con las flechas\n de tu telcado\nEn caso de que choques \nButters sera hospitalizado";
  texto [5] = "Presiona ENTER para emepezar a jugar";
  texto [6] = "Abril Funes\n118947/3";
  texto [7] ="Avril Fernandez \nCabrera 119027/4";
  texto [8] = "Apreta R para volver al inicio";
}
